# Deploy Keel to Render

This repository is configured as a Node.js web service for Render.

## Render settings

The included `render.yaml` specifies:

- Runtime: Node
- Build: `npm ci --no-audit --no-fund && npm run build`
- Start: `node .output/server/index.mjs`
- Health check: `/`
- `KEEL_DEPLOY_TARGET=render`, which selects Nitro's `node-server` output

The `.npmrc` enables npm's legacy peer-dependency resolver because the source
package tree currently reports an `ERESOLVE` conflict with npm's default resolver.

## Important deployment notes

- A successful ZIP integrity check is not the same as a successful application
  build. Run `npm ci` and `npm run build` in Codespaces or Render and resolve any
  remaining build-time errors before considering the deployment ready.
- Do not commit secrets. Configure any required credentials through Render's
  environment-variable settings.
- Without `DATABASE_URL`, the app uses its PGlite fallback. That fallback is
  not a durable database for a hosted service: data may be lost when the service
  restarts or is redeployed. Configure a persistent PostgreSQL database before
  relying on stored user data.
- The Render free service may sleep when idle and can take time to wake.
