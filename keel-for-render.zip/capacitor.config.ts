import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.keel.desk',
  appName: 'Keel',
  webDir: 'dist',
  server: {
    // When developing against a running local/dev server, uncomment and set:
    // url: 'http://YOUR_LAN_IP:8080',
    // cleartext: true,
    androidScheme: 'https',
  },
  android: {
    allowMixedContent: true,
    backgroundColor: '#f3efe7',
    buildOptions: {
      keystorePath: undefined,
      keystoreAlias: undefined,
    },
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 1200,
      backgroundColor: '#f3efe7',
      showSpinner: false,
      androidSplashResourceName: 'splash',
    },
    StatusBar: {
      style: 'LIGHT',
      backgroundColor: '#f3efe7',
    },
  },
};

export default config;
