import { useEffect, useState } from "react";
import { Toaster } from "sonner";
import { Chat } from "@/components/keel/chat";
import { Computer } from "@/components/keel/computer";
import { QuietDesk, Roster } from "@/components/keel/roster";
import { Sheets } from "@/components/keel/sheets";
import { useKeel } from "@/lib/keel/store";

export function KeelApp() {
  const screen = useKeel((s) => s.screen);
  const openBotId = useKeel((s) => s.openBotId);
  const bot = useKeel((s) => s.bots.find((item) => item.id === s.openBotId) ?? null);
  const [now, setNow] = useState<number | null>(null);

  useEffect(() => {
    void useKeel.persist.rehydrate();
    setNow(Date.now());
  }, []);

  const showRoster = screen === "roster";

  return (
    <main className="mx-auto flex h-dvh w-full max-w-6xl overflow-hidden bg-paper text-ink">
      <aside
        className={`min-h-0 w-full flex-col border-line lg:flex lg:w-96 lg:shrink-0 lg:border-r ${showRoster ? "flex" : "hidden"}`}
      >
        <Roster now={now} />
      </aside>
      <section className={`min-h-0 min-w-0 flex-1 flex-col ${showRoster ? "hidden lg:flex" : "flex"}`}>
        {bot && screen === "computer" ? <Computer bot={bot} /> : null}
        {bot && screen !== "computer" && !(showRoster && !openBotId) ? <Chat bot={bot} /> : null}
        {!bot || (showRoster && !openBotId) ? <QuietDesk /> : null}
      </section>
      <Sheets />
      <Toaster
        position="top-center"
        toastOptions={{
          style: {
            background: "var(--color-sheet)",
            color: "var(--color-ink)",
            border: "1px solid var(--color-line)",
          },
        }}
      />
    </main>
  );
}
