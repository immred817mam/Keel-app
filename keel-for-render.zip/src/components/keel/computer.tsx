import { useState } from "react";
import { ArrowLeft, Trash2 } from "lucide-react";
import { useKeel } from "@/lib/keel/store";
import type { Bot } from "@/lib/keel/types";

type Pane = "files" | "sources" | "memory";

export function Computer({ bot }: { bot: Bot }) {
  const setScreen = useKeel((s) => s.setScreen);
  const patchBot = useKeel((s) => s.patchBot);
  const [pane, setPane] = useState<Pane>("files");
  const [openPath, setOpenPath] = useState<string | null>(bot.files[0]?.path ?? null);
  const file = bot.files.find((item) => item.path === openPath) ?? null;

  return (
    <div className="flex h-full min-h-0 flex-col">
      <header className="safe-top flex shrink-0 items-center gap-2 border-b border-line px-2 pb-3">
        <button
          type="button"
          className="inline-flex size-11 items-center justify-center rounded-full"
          aria-label="Back to conversation"
          onClick={() => setScreen("chat")}
        >
          <ArrowLeft className="size-5" />
        </button>
        <div className="min-w-0">
          <h2 className="truncate font-display text-xl leading-tight">{bot.name}'s desk</h2>
          <p className="truncate text-xs text-muted">Files, sources, memory · shell available in chat</p>
        </div>
      </header>
      <div className="flex gap-2 px-4 py-3">
        {(
          [
            ["files", "Files"],
            ["sources", "Sources"],
            ["memory", "Memory"],
          ] as const
        ).map(([id, label]) => (
          <button
            key={id}
            type="button"
            className={`h-10 rounded-full px-3 text-sm ${pane === id ? "bg-ink text-copper-ink" : "border border-line bg-sheet"}`}
            onClick={() => setPane(id)}
          >
            {label}
          </button>
        ))}
      </div>
      <div className="keel-scroll min-h-0 flex-1 overflow-y-auto px-4 pb-8">
        {pane === "files" ? (
          bot.files.length === 0 ? (
            <p className="text-sm text-pretty text-muted">
              Nothing filed yet. Ask {bot.name.split(" ")[0]} to write a brief.
            </p>
          ) : (
            <div className="grid gap-3 lg:grid-cols-[14rem_1fr]">
              <ul className="flex flex-col gap-1">
                {bot.files.map((item) => (
                  <li key={item.path} className="flex items-center gap-1">
                    <button
                      type="button"
                      className={`min-w-0 flex-1 truncate rounded-xl px-3 py-2 text-left text-sm ${item.path === openPath ? "bg-copper-soft" : ""}`}
                      onClick={() => setOpenPath(item.path)}
                    >
                      {item.path}
                    </button>
                    <button
                      type="button"
                      className="inline-flex size-10 items-center justify-center text-muted"
                      aria-label={`Remove ${item.path}`}
                      onClick={() => {
                        const files = bot.files.filter((fileItem) => fileItem.path !== item.path);
                        patchBot(bot.id, { files });
                        if (openPath === item.path) setOpenPath(files[0]?.path ?? null);
                      }}
                    >
                      <Trash2 className="size-4" />
                    </button>
                  </li>
                ))}
              </ul>
              {file ? (
                <article className="rounded-2xl border border-line bg-sheet p-4">
                  <h3 className="text-sm font-medium">{file.path}</h3>
                  <p className="mt-3 text-sm whitespace-pre-wrap">{file.content}</p>
                </article>
              ) : null}
            </div>
          )
        ) : null}
        {pane === "sources" ? (
          bot.sources.length === 0 ? (
            <p className="text-sm text-muted">No sources yet. Ask for a lookup.</p>
          ) : (
            <ul className="flex flex-col gap-2">
              {bot.sources.map((source) => (
                <li key={source.url} className="rounded-2xl border border-line bg-sheet p-3">
                  <a href={source.url} target="_blank" rel="noreferrer" className="font-medium text-copper underline">
                    {source.title}
                  </a>
                  <p className="mt-1 text-sm text-pretty text-muted">{source.snippet}</p>
                </li>
              ))}
            </ul>
          )
        ) : null}
        {pane === "memory" ? (
          bot.memory.length === 0 ? (
            <p className="text-sm text-muted">Nothing remembered yet.</p>
          ) : (
            <ul className="flex flex-col gap-2">
              {bot.memory.map((fact) => (
                <li key={fact} className="flex items-start gap-2 rounded-2xl border border-line bg-sheet px-3 py-3 text-sm">
                  <span className="min-w-0 flex-1">{fact}</span>
                  <button
                    type="button"
                    className="inline-flex size-10 shrink-0 items-center justify-center text-muted"
                    aria-label="Forget this"
                    onClick={() =>
                      patchBot(bot.id, { memory: bot.memory.filter((item) => item !== fact) })
                    }
                  >
                    <Trash2 className="size-4" />
                  </button>
                </li>
              ))}
            </ul>
          )
        ) : null}
      </div>
    </div>
  );
}
