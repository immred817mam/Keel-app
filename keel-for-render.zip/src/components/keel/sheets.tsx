import { useEffect, useState } from "react";
import { X } from "lucide-react";
import { useKeel, uid } from "@/lib/keel/store";
import type { BotShape, Engine } from "@/lib/keel/types";

const ENGINES: { id: Engine; label: string; hint: string }[] = [
  { id: "open", label: "Open model", hint: "Free. No key. gpt-oss 20B." },
  { id: "groq", label: "Groq", hint: "Free key from console.groq.com." },
  { id: "gemini", label: "Gemini", hint: "Free key from Google AI Studio." },
  { id: "openrouter", label: "OpenRouter", hint: "A free model id, your key." },
];

export function Sheets() {
  const sheet = useKeel((s) => s.sheet);
  const setSheet = useKeel((s) => s.setSheet);
  if (!sheet) return null;
  return (
    <div className="fixed inset-0 z-30 flex items-end justify-center bg-ink/40 sm:items-center">
      <button type="button" className="absolute inset-0" aria-label="Close" onClick={() => setSheet(null)} />
      <div className="safe-bottom relative z-10 max-h-[88dvh] w-full overflow-y-auto rounded-t-3xl bg-paper px-5 pt-4 sm:max-w-md sm:rounded-3xl">
        <div className="mb-3 flex items-center justify-between">
          <h2 className="font-display text-2xl">
            {sheet === "settings" ? "Settings" : null}
            {sheet === "create" ? "New coworker" : null}
            {sheet === "edit" ? "Coworker" : null}
            {sheet === "install" ? "On your phone" : null}
          </h2>
          <button
            type="button"
            className="inline-flex size-11 items-center justify-center rounded-full"
            aria-label="Close"
            onClick={() => setSheet(null)}
          >
            <X className="size-5" />
          </button>
        </div>
        {sheet === "settings" ? <SettingsForm /> : null}
        {sheet === "create" ? <CreateForm /> : null}
        {sheet === "edit" ? <EditForm /> : null}
        {sheet === "install" ? <InstallHelp /> : null}
      </div>
    </div>
  );
}

function SettingsForm() {
  const settings = useKeel((s) => s.settings);
  const setSettings = useKeel((s) => s.setSettings);
  const loadSample = useKeel((s) => s.loadSample);
  const clearDesk = useKeel((s) => s.clearDesk);
  const setSheet = useKeel((s) => s.setSheet);
  return (
    <div className="flex flex-col gap-4 pb-6">
      <fieldset>
        <legend className="text-sm font-medium">Engine</legend>
        <div className="mt-2 flex flex-col gap-2">
          {ENGINES.map((engine) => (
            <label
              key={engine.id}
              className={`flex cursor-pointer items-start gap-3 rounded-2xl border px-3 py-3 ${settings.engine === engine.id ? "border-ink bg-sheet" : "border-line"}`}
            >
              <input
                type="radio"
                name="engine"
                className="mt-1"
                checked={settings.engine === engine.id}
                onChange={() => setSettings({ engine: engine.id })}
              />
              <span>
                <span className="block text-sm font-medium">{engine.label}</span>
                <span className="block text-xs text-muted">{engine.hint}</span>
              </span>
            </label>
          ))}
        </div>
      </fieldset>
      {settings.engine !== "open" ? (
        <label className="block text-sm">
          API key
          <input
            type="password"
            autoComplete="off"
            value={settings.apiKey}
            placeholder="Stored only on this phone"
            className="mt-1 h-11 w-full rounded-xl border border-line bg-sheet px-3 text-sm outline-none"
            onChange={(event) => setSettings({ apiKey: event.target.value })}
          />
        </label>
      ) : null}
      <label className="block text-sm">
        Model id <span className="text-muted">optional</span>
        <input
          value={settings.model}
          placeholder={
            settings.engine === "groq"
              ? "llama-3.3-70b-versatile"
              : settings.engine === "gemini"
                ? "gemini-2.5-flash"
                : settings.engine === "openrouter"
                  ? "meta-llama/llama-3.3-70b-instruct:free"
                  : "gpt-oss-20b"
          }
          className="mt-1 h-11 w-full rounded-xl border border-line bg-sheet px-3 text-sm outline-none"
          onChange={(event) => setSettings({ model: event.target.value })}
        />
      </label>
      <p className="text-sm text-pretty text-muted">
        The open lane calls a public, keyless API that serves gpt-oss, an open-weight model. Nothing
        you type is stored on a Keel account — there isn't one. A pasted key is sent only to that
        provider, and only when you send a message.
      </p>
      <div className="flex flex-col gap-2">
        <button
          type="button"
          className="h-11 rounded-full border border-line bg-sheet text-sm"
          onClick={() => {
            loadSample();
            setSheet(null);
          }}
        >
          Load the sample desk
        </button>
        <button
          type="button"
          className="h-11 rounded-full text-sm text-copper"
          onClick={() => {
            clearDesk();
            setSheet(null);
          }}
        >
          Clear this desk
        </button>
      </div>
    </div>
  );
}

function CreateForm() {
  const addBot = useKeel((s) => s.addBot);
  const openBot = useKeel((s) => s.openBot);
  const setSheet = useKeel((s) => s.setSheet);
  const count = useKeel((s) => s.bots.length);
  const [name, setName] = useState("");
  const [role, setRole] = useState("");
  const [brief, setBrief] = useState("");
  const shapes: BotShape[] = ["circle", "squircle", "tile"];

  function create() {
    const cleanName = name.trim();
    const cleanRole = role.trim() || "Generalist";
    if (!cleanName) return;
    const id = uid();
    addBot({
      id,
      name: cleanName,
      role: cleanRole,
      brief:
        brief.trim() ||
        `You handle ${cleanRole.toLowerCase()}. You are specific, you file work on the desk, and you wait for approval before anything is shared.`,
      shape: shapes[count % shapes.length] ?? "circle",
      tone: count % 2 === 0 ? "ink" : "copper",
      status: "idle",
      statusLine: "Just arrived.",
      updatedAt: Date.now(),
      unread: 0,
      memory: [],
      files: [],
      sources: [],
      routines: [],
      prompts: [`Help me with ${cleanRole.toLowerCase()}`, "Keep it shorter"],
    });
    openBot(id);
    setSheet(null);
  }

  return (
    <form
      className="flex flex-col gap-3 pb-6"
      onSubmit={(event) => {
        event.preventDefault();
        create();
      }}
    >
      <Field label="Name" value={name} onChange={setName} placeholder="Mina Cole" />
      <Field label="Role" value={role} onChange={setRole} placeholder="Notes" />
      <label className="block text-sm">
        How they should work
        <textarea
          value={brief}
          rows={3}
          placeholder="Plain language, short drafts, ask before anything leaves."
          className="mt-1 w-full resize-none rounded-xl border border-line bg-sheet px-3 py-2 text-sm outline-none"
          onChange={(event) => setBrief(event.target.value)}
        />
      </label>
      <button
        type="submit"
        disabled={!name.trim()}
        className="h-11 rounded-full bg-copper text-sm font-medium text-copper-ink disabled:opacity-40"
      >
        Add to the desk
      </button>
    </form>
  );
}

function EditForm() {
  const bot = useKeel((s) => s.bots.find((item) => item.id === s.openBotId) ?? null);
  const patchBot = useKeel((s) => s.patchBot);
  const removeBot = useKeel((s) => s.removeBot);
  const [label, setLabel] = useState("");
  const [prompt, setPrompt] = useState("");
  const [confirm, setConfirm] = useState(false);
  if (!bot) return <p className="pb-6 text-sm text-muted">Pick a coworker first.</p>;

  return (
    <div className="flex flex-col gap-3 pb-6">
      <Field
        label="Name"
        value={bot.name}
        onChange={(name) => patchBot(bot.id, { name })}
      />
      <Field label="Role" value={bot.role} onChange={(role) => patchBot(bot.id, { role })} />
      <label className="block text-sm">
        How they should work
        <textarea
          value={bot.brief}
          rows={4}
          className="mt-1 w-full resize-none rounded-xl border border-line bg-sheet px-3 py-2 text-sm outline-none"
          onChange={(event) => patchBot(bot.id, { brief: event.target.value })}
        />
      </label>
      <div>
        <p className="text-sm font-medium">Routines</p>
        <ul className="mt-2 flex flex-col gap-2">
          {bot.routines.map((routine) => (
            <li key={routine.id} className="rounded-xl border border-line bg-sheet px-3 py-2 text-sm">
              <span className="font-medium">{routine.label}</span>
              <span className="mt-1 block text-xs text-muted">{routine.prompt}</span>
              <button
                type="button"
                className="mt-1 text-xs text-copper"
                onClick={() =>
                  patchBot(bot.id, {
                    routines: bot.routines.filter((item) => item.id !== routine.id),
                  })
                }
              >
                Remove
              </button>
            </li>
          ))}
        </ul>
        <div className="mt-2 flex flex-col gap-2">
          <Field label="Routine name" value={label} onChange={setLabel} placeholder="Friday cleanup" />
          <Field
            label="What to ask"
            value={prompt}
            onChange={setPrompt}
            placeholder="List anything still open from this week."
          />
          <button
            type="button"
            className="h-10 rounded-full border border-line text-sm"
            onClick={() => {
              if (!label.trim() || !prompt.trim()) return;
              patchBot(bot.id, {
                routines: bot.routines.concat({
                  id: uid(),
                  label: label.trim(),
                  prompt: prompt.trim(),
                  when: "manual",
                  lastRun: Date.now(),
                }),
              });
              setLabel("");
              setPrompt("");
            }}
          >
            Add routine
          </button>
        </div>
      </div>
      {confirm ? (
        <div className="flex gap-2">
          <button
            type="button"
            className="h-11 flex-1 rounded-full bg-copper text-sm text-copper-ink"
            onClick={() => removeBot(bot.id)}
          >
            Remove {bot.name.split(" ")[0]}
          </button>
          <button type="button" className="h-11 flex-1 rounded-full border border-line text-sm" onClick={() => setConfirm(false)}>
            Cancel
          </button>
        </div>
      ) : (
        <button type="button" className="h-11 text-sm text-copper" onClick={() => setConfirm(true)}>
          Remove from the desk
        </button>
      )}
    </div>
  );
}

function InstallHelp() {
  const setSettings = useKeel((s) => s.setSettings);
  const setSheet = useKeel((s) => s.setSheet);
  const [canInstall, setCanInstall] = useState(false);
  const [promptEvent, setPromptEvent] = useState<BeforeInstallPromptEvent | null>(null);

  useEffect(() => {
    const onPrompt = (event: Event) => {
      event.preventDefault();
      setPromptEvent(event as BeforeInstallPromptEvent);
      setCanInstall(true);
    };
    window.addEventListener("beforeinstallprompt", onPrompt);
    return () => window.removeEventListener("beforeinstallprompt", onPrompt);
  }, []);

  return (
    <div className="flex flex-col gap-3 pb-6 text-sm">
      <p className="text-pretty text-muted">
        Keel is a full-screen phone app. On Android, add it to the home screen. Chrome keeps your desk
        on the device.
      </p>
      <ol className="space-y-2">
        <li>1. Open the browser menu.</li>
        <li>2. Choose Add to Home screen, or Install app.</li>
        <li>3. Open Keel from the icon. It stays full screen.</li>
      </ol>
      {canInstall ? (
        <button
          type="button"
          className="h-11 rounded-full bg-copper font-medium text-copper-ink"
          onClick={() => {
            void promptEvent?.prompt();
          }}
        >
          Install
        </button>
      ) : null}
      <button
        type="button"
        className="h-11 rounded-full border border-line"
        onClick={() => {
          setSettings({ installHint: false });
          setSheet(null);
        }}
      >
        Hide the hint
      </button>
    </div>
  );
}

function Field({
  label,
  value,
  onChange,
  placeholder,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
}) {
  return (
    <label className="block text-sm">
      {label}
      <input
        value={value}
        placeholder={placeholder}
        className="mt-1 h-11 w-full rounded-xl border border-line bg-sheet px-3 text-sm outline-none"
        onChange={(event) => onChange(event.target.value)}
      />
    </label>
  );
}

type BeforeInstallPromptEvent = Event & {
  prompt: () => Promise<void>;
};
